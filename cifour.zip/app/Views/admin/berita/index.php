<?php 
echo view('admin/dasbor/index');
